"use client"
// Threat-focused panels including watch, actions, devices, and blocked sites.

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { 
  AlertTriangle, 
  ChevronLeft, 
  ChevronRight, 
  MapPin, 
  RefreshCw, 
  Shield, 
  Smartphone, 
  Wifi, 
  Zap,
  Layers,
  ExternalLink,
  ShieldAlert,
  Info
} from "lucide-react"
import {
  clearBlockedSites,
  getBlockedSites,
  getProxyStatus,
  getThreats,
  respondToThreat,
  unblockSite,
  Threat,
  type BlockedSite,
  type ProxyClient,
} from "@/lib/api"

const DASHBOARD_REFRESH_EVENT = "netguard:dashboard-refresh"

function emitDashboardRefresh() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(DASHBOARD_REFRESH_EVENT))
  }
}

function getSeverityClass(severity: Threat["severity"]) {
  if (severity === "CRITICAL") return "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-900/50"
  if (severity === "HIGH") return "bg-orange-50 dark:bg-orange-950/20 border-orange-200 dark:border-orange-900/50"
  if (severity === "MEDIUM") return "bg-yellow-50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-900/50"
  return "bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900/50"
}

function formatStatus(status: string) {
  return status.replace(/_/g, " ").replace(/\b\w/g, (match) => match.toUpperCase())
}

function formatThreatType(type: string) {
  return type.replace(/_/g, " ").replace(/\b\w/g, (match) => match.toUpperCase())
}

function getSeverityRank(severity: Threat["severity"]) {
  if (severity === "CRITICAL") return 4
  if (severity === "HIGH") return 3
  if (severity === "MEDIUM") return 2
  return 1
}

function isPrivateNetworkAddress(value?: string) {
  if (!value) return false
  if (value.startsWith("10.") || value.startsWith("192.168.")) return true
  const octets = value.split(".")
  if (octets.length < 2 || octets[0] !== "172") return false
  const secondOctet = Number(octets[1])
  return Number.isFinite(secondOctet) && secondOctet >= 16 && secondOctet <= 31
}

function formatThreatSource(sourceIp: string) {
  if (isPrivateNetworkAddress(sourceIp)) {
    return `Local device ${sourceIp}`
  }
  return sourceIp
}

function ThreatInvestigationModal({
  threat,
  open,
  onOpenChange,
  onBlockAction
}: {
  threat: Threat | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onBlockAction: (threatId: string) => void
}) {
  if (!threat) return null

  const isDemo = (threat as any).is_demo ?? true
  const originLabel = (threat as any).origin || (isDemo ? "DEMO / SEEDED DATA" : "LIVE CAPTURE DETECTION")
  const mitre = threat.mitre_mapping || {}

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl border bg-card p-6 shadow-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="space-y-2 border-b pb-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={isDemo ? "bg-amber-500/10 text-amber-500 border-amber-500/30 font-bold" : "bg-emerald-500/10 text-emerald-500 border-emerald-500/30 font-bold"}>
                {originLabel}
              </Badge>
              <Badge className={threat.severity === "CRITICAL" ? "bg-red-600 text-white font-bold" : threat.severity === "HIGH" ? "bg-orange-600 text-white font-bold" : "bg-yellow-600 text-white font-bold"}>
                {threat.severity} SEVERITY
              </Badge>
            </div>
            <span className="text-xs text-muted-foreground font-mono">ID: {threat.id}</span>
          </div>

          <DialogTitle className="text-xl font-bold flex items-center gap-2 text-foreground">
            <ShieldAlert className="h-5 w-5 text-red-500" />
            Threat Forensics: {formatThreatType(threat.type)}
          </DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground">
            Deep packet inspection investigation, MITRE ATT&CK kill-chain mapping, and recommended response playbooks.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 py-4">
          {/* Overview Metric Grid */}
          <div className="grid gap-3 sm:grid-cols-3 text-xs">
            <div className="rounded-lg bg-muted p-3">
              <span className="text-muted-foreground uppercase text-[10px] font-semibold">Source Device</span>
              <p className="font-semibold text-sm mt-0.5">{formatThreatSource(threat.source_ip)}</p>
            </div>
            <div className="rounded-lg bg-muted p-3">
              <span className="text-muted-foreground uppercase text-[10px] font-semibold">Target Host</span>
              <p className="font-semibold text-sm mt-0.5 truncate">{threat.destination_host || threat.destination_ip || "Unknown"}</p>
            </div>
            <div className="rounded-lg bg-muted p-3">
              <span className="text-muted-foreground uppercase text-[10px] font-semibold">Confidence Score</span>
              <p className="font-semibold text-sm mt-0.5 text-sky-500">{((threat.threat_score || 0.9) * 100).toFixed(0)}%</p>
            </div>
          </div>

          {/* MITRE Vector Detail Box */}
          <div className="rounded-xl border bg-purple-500/10 border-purple-500/30 p-4 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-purple-400 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                <Layers className="h-4 w-4 text-purple-400" />
                MITRE ATT&CK Kill-Chain Mapping
              </span>
              <Badge className="bg-purple-600 text-white font-bold">{mitre.stage_label || threat.attack_stage || "Stage 4: Execution"}</Badge>
            </div>
            <div className="grid gap-2 sm:grid-cols-2 pt-1 text-muted-foreground">
              <div>
                <span className="font-medium text-foreground">Technique ID: </span>
                <span className="font-mono text-purple-400 font-bold">{mitre.technique_id || threat.technique_id || "T1204.002"}</span>
              </div>
              <div>
                <span className="font-medium text-foreground">Technique: </span>
                <span>{mitre.technique_name || threat.technique_name || "User Execution: Malicious File"}</span>
              </div>
              <div className="sm:col-span-2">
                <span className="font-medium text-foreground">Tactic: </span>
                <span>{mitre.tactic_name || "Execution"} ({mitre.tactic_id || "TA0002"})</span>
              </div>
            </div>
          </div>

          {/* Alert Description & Evidence */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Detection Reason & Evidence</h4>
            <div className="rounded-lg bg-muted p-3 text-xs space-y-2">
              <p className="font-medium text-foreground">{threat.description}</p>
              {threat.evidence && threat.evidence.length > 0 && (
                <ul className="list-disc list-inside space-y-1 text-muted-foreground pt-1 border-t border-border">
                  {threat.evidence.map((ev, i) => (
                    <li key={i}>{ev}</li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* Recommended Mitigations */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Recommended Incident Response Playbook</h4>
            <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs space-y-1">
              <p className="font-semibold text-amber-500">NetGuard Recommended Playbook Actions:</p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li>Enforce NetGuard local proxy domain block for target <span className="font-mono font-semibold text-foreground">{threat.destination_host || threat.source_ip}</span>.</li>
                <li>Terminate active TCP socket stream from host <span className="font-mono font-semibold text-foreground">{threat.source_ip}</span>.</li>
                <li>Revoke active session tokens and review EDR process tree.</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex flex-col sm:flex-row gap-3 justify-between pt-3 border-t">
          <Button
            variant="destructive"
            onClick={() => {
              onBlockAction(threat.id)
              onOpenChange(false)
            }}
            disabled={threat.status === "blocked"}
          >
            {threat.status === "blocked" ? "Proxy Domain Blocked" : "Enforce Proxy Domain Block"}
          </Button>

          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close Investigation
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

interface ThreatDetectionPanelProps {
  excludeLow?: boolean
}

export function ThreatDetectionPanel({ excludeLow = false }: ThreatDetectionPanelProps) {
  const [threats, setThreats] = useState<Threat[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [message, setMessage] = useState("")
  const [activeIndex, setActiveIndex] = useState(0)
  const [investigatingThreat, setInvestigatingThreat] = useState<Threat | null>(null)
  const [modalOpen, setModalOpen] = useState(false)
  const [currentMode, setCurrentMode] = useState<"live" | "demo">("live")

  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = (localStorage.getItem("netguard_app_mode") as "live" | "demo") || "live"
      setCurrentMode(stored)

      const handleModeChange = (e: any) => {
        if (e.detail?.mode) {
          setCurrentMode(e.detail.mode)
        }
      }

      window.addEventListener("netguard:mode-change", handleModeChange)
      return () => window.removeEventListener("netguard:mode-change", handleModeChange)
    }
  }, [])

  const fetchThreats = async () => {
    try {
      setLoading(true)
      const data = await getThreats("active", undefined, currentMode)
      setThreats((data.threats || []).filter((threat) => threat.status !== "ignored"))
      setError("")
    } catch (err: any) {
      console.error("Failed to fetch threats:", err)
      setError("Failed to load threats")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    let isMounted = true
    const load = async () => {
      try {
        const data = await getThreats("active", undefined, currentMode)
        if (isMounted) {
          setThreats((data.threats || []).filter((threat) => threat.status !== "ignored"))
          setError("")
          setLoading(false)
        }
      } catch (err: any) {
        if (isMounted) {
          console.error("Failed to fetch threats:", err)
          setError("Failed to load threats")
          setLoading(false)
        }
      }
    }

    load()
    const interval = setInterval(load, 5000)
    const handleRefresh = () => load()
    window.addEventListener(DASHBOARD_REFRESH_EVENT, handleRefresh)

    return () => {
      isMounted = false
      clearInterval(interval)
      window.removeEventListener(DASHBOARD_REFRESH_EVENT, handleRefresh)
    }
  }, [currentMode])

  const handleThreatAction = async (threatId: string, action: string) => {
    try {
      const result = await respondToThreat(threatId, action)
      setMessage(result.message || `Threat ${action.toLowerCase()} completed`)
      emitDashboardRefresh()
      await fetchThreats()
    } catch (err: any) {
      setMessage(err?.message || "Failed to respond to threat")
    }
  }

  const handleOpenInvestigate = (threat: Threat) => {
    setInvestigatingThreat(threat)
    setModalOpen(true)
    handleThreatAction(threat.id, "INVESTIGATE")
  }

  const visibleThreats = threats
    .filter((threat) => !excludeLow || threat.severity !== "LOW")
    .sort((left, right) => {
      const severityDifference = getSeverityRank(right.severity) - getSeverityRank(left.severity)
      if (severityDifference !== 0) {
        return severityDifference
      }
      return new Date(right.timestamp).getTime() - new Date(left.timestamp).getTime()
    })

  const safeActiveIndex = visibleThreats.length > 0
    ? Math.min(activeIndex, visibleThreats.length - 1)
    : 0
  const activeThreat = visibleThreats[safeActiveIndex] ?? null

  if (loading && threats.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            Threats Detected
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-500">Loading threats...</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            Threat Watch ({visibleThreats.length})
          </CardTitle>
          <Button size="sm" variant="ghost" onClick={fetchThreats}>
            <RefreshCw className="w-4 h-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-3">
          {error && <div className="text-red-500 text-sm">{error}</div>}
          {message && <div className="text-xs bg-muted p-2 rounded text-slate-600 font-medium">{message}</div>}

          {visibleThreats.length === 0 || !activeThreat ? (
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-center space-y-1">
              <div className="flex items-center justify-center gap-2">
                <Badge variant="outline" className={currentMode === "live" ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/30 text-[10px] font-bold" : "bg-amber-500/10 text-amber-500 border-amber-500/30 text-[10px] font-bold"}>
                  {currentMode === "live" ? "LIVE CAPTURE DETECTION" : "DEMO / SEEDED DATA"}
                </Badge>
              </div>
              <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400">
                {currentMode === "live" ? "No Live Threats Detected" : "No Demo Threats Loaded"}
              </p>
              <p className="text-xs text-muted-foreground">
                {currentMode === "live"
                  ? "Monitored Npcap network traffic is clean. Zero anomalous flows detected."
                  : "Switch to LIVE MODE or click refresh to load demo attack scenarios."}
              </p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between gap-3">
                <p className="text-xs text-slate-500">
                  Threat {safeActiveIndex + 1} of {visibleThreats.length}
                </p>
                {visibleThreats.length > 1 && (
                  <div className="flex items-center gap-1">
                    <Button
                      size="icon"
                      variant="outline"
                      className="h-8 w-8"
                      onClick={() => setActiveIndex((currentIndex) => Math.max(0, currentIndex - 1))}
                      disabled={safeActiveIndex === 0}
                    >
                      <ChevronLeft className="h-4 w-4" />
                      <span className="sr-only">Previous threat</span>
                    </Button>
                    <Button
                      size="icon"
                      variant="outline"
                      className="h-8 w-8"
                      onClick={() => setActiveIndex((currentIndex) => Math.min(visibleThreats.length - 1, currentIndex + 1))}
                      disabled={safeActiveIndex === visibleThreats.length - 1}
                    >
                      <ChevronRight className="h-4 w-4" />
                      <span className="sr-only">Next threat</span>
                    </Button>
                  </div>
                )}
              </div>
              <div
                key={activeThreat.id}
                className={`rounded-2xl border p-4 shadow-sm ${getSeverityClass(activeThreat.severity)}`}
              >
                {/* Threat Header & Data Origin Badge */}
                <div className="mb-3 flex flex-col gap-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <Badge variant="outline" className={(activeThreat as any).is_demo ?? true ? "bg-amber-500/10 text-amber-500 border-amber-500/30 text-[10px] font-bold" : "bg-emerald-500/10 text-emerald-500 border-emerald-500/30 text-[10px] font-bold"}>
                      {(activeThreat as any).origin || ((activeThreat as any).is_demo ?? true ? "DEMO / SEEDED DATA" : "LIVE CAPTURE DETECTION")}
                    </Badge>

                    <div className="flex items-center gap-1.5">
                      <Badge
                        variant={activeThreat.severity === "CRITICAL" ? "destructive" : "default"}
                        className={
                          activeThreat.severity === "HIGH"
                            ? "bg-orange-600"
                            : activeThreat.severity === "MEDIUM"
                              ? "bg-yellow-600"
                              : "bg-blue-600"
                        }
                      >
                        {activeThreat.severity}
                      </Badge>
                      <Badge variant="outline">{formatStatus(activeThreat.status)}</Badge>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">{formatThreatType(activeThreat.type)}</p>
                    {activeThreat.attack_stage || activeThreat.mitre_mapping?.stage_label ? (
                      <Badge className="bg-purple-600 hover:bg-purple-700 text-[10px] text-white font-bold px-2 py-0.5 flex items-center gap-1">
                        <Layers className="w-3 h-3" />
                        {activeThreat.attack_stage || activeThreat.mitre_mapping?.stage_label}
                      </Badge>
                    ) : null}
                  </div>
                </div>

                {/* MITRE ATT&CK & Threat Vector Info Strip */}
                {(activeThreat.mitre_mapping || activeThreat.technique_id) && (
                  <div className="mb-3 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900/50 p-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-1.5 font-medium text-purple-900 dark:text-purple-200">
                      <ShieldAlert className="w-3.5 h-3.5 text-purple-600" />
                      <span>MITRE Vector:</span>
                      <span className="font-mono font-bold text-indigo-700 dark:text-indigo-300">
                        {activeThreat.technique_id || activeThreat.mitre_mapping?.technique_id}
                      </span>
                      <span>-</span>
                      <span>{activeThreat.technique_name || activeThreat.mitre_mapping?.technique_name}</span>
                    </div>
                    {activeThreat.mitre_mapping?.reference_url && (
                      <a
                        href={activeThreat.mitre_mapping.reference_url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-purple-600 hover:text-purple-800 dark:text-purple-400 font-medium flex items-center gap-0.5"
                      >
                        MITRE ATT&CK Info <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                )}

                <div className="mb-3 grid gap-2 sm:grid-cols-2">
                  <div className="rounded-xl bg-white/75 dark:bg-slate-900/75 px-3 py-2">
                    <p className="text-[11px] uppercase tracking-wide text-slate-500">Device</p>
                    <p className="mt-1 flex items-center gap-2 text-sm font-medium text-slate-900 dark:text-slate-100">
                      <Smartphone className="h-4 w-4 text-slate-500" />
                      {formatThreatSource(activeThreat.source_ip)}
                    </p>
                  </div>
                  <div className="rounded-xl bg-white/75 dark:bg-slate-900/75 px-3 py-2">
                    <p className="text-[11px] uppercase tracking-wide text-slate-500">Target</p>
                    <p className="mt-1 break-all text-sm font-medium text-slate-900 dark:text-slate-100">
                      {activeThreat.destination_host || activeThreat.destination_ip || "Unknown target"}
                    </p>
                  </div>
                  {activeThreat.destination_ip && (
                    <div className="rounded-xl bg-white/75 dark:bg-slate-900/75 px-3 py-2">
                      <p className="text-[11px] uppercase tracking-wide text-slate-500">Resolved IP</p>
                      <p className="mt-1 flex items-center gap-2 text-sm font-medium text-slate-900 dark:text-slate-100">
                        <MapPin className="h-4 w-4 text-slate-500" />
                        {activeThreat.destination_ip}
                        {activeThreat.destination_port ? `:${activeThreat.destination_port}` : ""}
                      </p>
                    </div>
                  )}
                  <div className="rounded-xl bg-white/75 dark:bg-slate-900/75 px-3 py-2">
                    <p className="text-[11px] uppercase tracking-wide text-slate-500">Confidence</p>
                    <p className="mt-1 text-sm font-medium text-slate-900 dark:text-slate-100">
                      {((activeThreat.threat_score || 0.9) * 100).toFixed(0)}%
                    </p>
                  </div>
                </div>

                <div className="rounded-xl bg-white/70 dark:bg-slate-900/70 px-3 py-3">
                  <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Alert message</p>
                  <p className="mt-2 text-sm text-slate-700 dark:text-slate-300">{activeThreat.description}</p>
                </div>

                {activeThreat.evidence && activeThreat.evidence.length > 0 && (
                  <div className="mb-3 mt-3 space-y-1">
                    {activeThreat.evidence.slice(0, 2).map((item, index) => (
                      <p key={`${activeThreat.id}-evidence-${index}`} className="text-xs text-slate-500">
                        • {item}
                      </p>
                    ))}
                  </div>
                )}

                <div className="flex flex-col gap-2 sm:flex-row mt-4">
                  <Button
                    size="sm"
                    className="bg-red-600 text-xs hover:bg-red-700 sm:flex-1 text-white"
                    onClick={() => handleThreatAction(activeThreat.id, "BLOCK")}
                    disabled={activeThreat.status === "blocked"}
                  >
                    {activeThreat.status === "blocked" ? "Blocked" : "Block"}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-xs sm:flex-1"
                    onClick={() => handleOpenInvestigate(activeThreat)}
                  >
                    Investigate
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Threat Investigation Details Modal */}
      <ThreatInvestigationModal
        threat={investigatingThreat}
        open={modalOpen}
        onOpenChange={setModalOpen}
        onBlockAction={(id) => handleThreatAction(id, "BLOCK")}
      />
    </>
  )
}

export function ObservedDevicesCard() {
  const [clients, setClients] = useState<ProxyClient[]>([])
  const [proxyListening, setProxyListening] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let isMounted = true
    const fetchProxyDevices = async () => {
      try {
        const status = await getProxyStatus()
        if (isMounted) {
          setProxyListening(status.enabled && status.listening)
          setClients(status.clients || [])
          setLoading(false)
        }
      } catch (error) {
        if (isMounted) {
          console.error("Failed to fetch proxy status:", error)
          setLoading(false)
        }
      }
    }

    fetchProxyDevices()
    const interval = setInterval(fetchProxyDevices, 3000)
    return () => {
      isMounted = false
      clearInterval(interval)
    }
  }, [])

  const hasActiveClient = clients.length > 0
  const activeClientCount = clients.length

  return (
    <Card className="border-border bg-card">
      <CardHeader className="flex flex-row items-center justify-between gap-3">
        <CardTitle className="flex items-center gap-2">
          <Wifi className="h-5 w-5" />
          Observed Devices
        </CardTitle>
        <Badge variant="outline">{activeClientCount} live</Badge>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="rounded-2xl bg-slate-50 dark:bg-slate-900/50 p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                {hasActiveClient
                  ? `${activeClientCount} device${activeClientCount === 1 ? "" : "s"} currently online`
                  : proxyListening
                    ? "Waiting for phone traffic"
                    : "Phone proxy is offline"}
              </p>
              <p className="text-xs text-slate-500">
                {hasActiveClient
                  ? "These devices sent traffic through the monitored proxy within the last 15 seconds."
                  : proxyListening
                    ? "A device is marked live only when traffic is seen in the last 15 seconds."
                    : "Start capture mode to watch phone traffic."}
              </p>
            </div>
            <Badge
              variant={hasActiveClient ? "default" : "outline"}
              className={hasActiveClient ? "bg-emerald-600" : proxyListening ? "bg-amber-600 text-white" : ""}
            >
              {hasActiveClient ? "LIVE" : proxyListening ? "IDLE" : "OFF"}
            </Badge>
          </div>
        </div>

        {loading ? (
          <p className="text-sm text-slate-500">Loading observed devices...</p>
        ) : clients.length === 0 ? (
          <div className="rounded-xl border border-dashed p-4 text-center text-xs text-slate-500">
            No live proxy devices connected. Start capturing traffic to populate.
          </div>
        ) : (
          <div className="space-y-2">
            {clients.map((client) => (
              <div key={client.ip} className="flex items-center justify-between rounded-xl border bg-card p-3 text-xs">
                <div className="flex items-center gap-2">
                  <Smartphone className="h-4 w-4 text-slate-500" />
                  <span className="font-medium">{client.ip}</span>
                </div>
                <span className="text-muted-foreground">{client.bytes_transferred || 0} bytes</span>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export function BlockedSitesCard() {
  const [blockedSites, setBlockedSites] = useState<BlockedSite[]>([])
  const [loading, setLoading] = useState(true)

  const fetchBlocked = async () => {
    try {
      const data = await getBlockedSites()
      setBlockedSites(data.blocked_sites || [])
    } catch (err) {
      console.error("Failed to fetch blocked sites:", err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchBlocked()
    const interval = setInterval(fetchBlocked, 5000)
    return () => clearInterval(interval)
  }, [])

  const handleUnblock = async (domain: str) => {
    try {
      await unblockSite(domain)
      fetchBlocked()
      emitDashboardRefresh()
    } catch (err) {
      console.error("Failed to unblock site:", err)
    }
  }

  const handleClearAll = async () => {
    try {
      await clearBlockedSites()
      fetchBlocked()
      emitDashboardRefresh()
    } catch (err) {
      console.error("Failed to clear blocked sites:", err)
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-base font-semibold">Blocked Domains ({blockedSites.length})</CardTitle>
        {blockedSites.length > 0 && (
          <Button size="sm" variant="outline" onClick={handleClearAll} className="text-xs">
            Clear All Blocks
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {loading ? (
          <p className="text-xs text-muted-foreground">Loading blocked sites...</p>
        ) : blockedSites.length === 0 ? (
          <p className="text-xs text-muted-foreground">No domains currently blocked by NetGuard proxy rules.</p>
        ) : (
          <div className="space-y-2">
            {blockedSites.map((site) => (
              <div key={site.domain} className="flex items-center justify-between rounded-lg border bg-muted/40 p-2.5 text-xs">
                <div>
                  <span className="font-mono font-bold text-foreground">{site.domain}</span>
                  <span className="ml-2 text-[10px] text-muted-foreground">({site.reason})</span>
                </div>
                <Button size="sm" variant="ghost" onClick={() => handleUnblock(site.domain)} className="h-7 text-xs text-destructive hover:bg-destructive/10">
                  Unblock
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export function ThreatResponsePanel() {
  return null
}

export function OSProtection() {
  return null
}
